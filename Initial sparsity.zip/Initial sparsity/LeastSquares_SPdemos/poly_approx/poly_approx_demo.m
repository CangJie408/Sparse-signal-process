%% Least square polynomial approximation
% This example illustrates the fitting of a low-order polynomial to data by
% least squares.
%
%  Ivan Selesnick
% selesi@poly.edu

%% Start

clear
close all

%% Load data

load data.txt;
whos

t = data(:, 1);         % time index
y = data(:, 2);         % data value

%% Display data

figure(1) % 创建图像窗口
clf       % 清除当前图像窗口
plot(t, y, '.')
title('Data')

%% Polynomial approximation (degree = 2)
% A is a matrix of size 100 rows, 3 columns
% 多项式逼近
A = bsxfun(@power, t, [2 1 0]);       % Raise t to powers 2, 1, 0   power按元素进行求幂
size(A)

%%
% A'*A is a matrix of size 3 by 3

A'*A 

%% 
% Solve the system A'*A*p = A'*y for p
% using the backslash.
% p is a vector of length 3.

p = (A'*A) \ (A'*y) % 对线性方程组Ax = B进行求解，语法x = A\B，这里的P相当于文档里的a

%%
% Display polynomial approximation

subplot(2,2,1);
plot(t, polyval(p, t), t, y, '.')            % polyval--->多项式计算
title('Polynomial approximation (degree = 2)')
xlabel('t')
ylabel('plyval(p,t)-degree')

%% Polynomial approximation (degree = 3)

A = bsxfun(@power, t, [3 2 1 0]);
p = (A'*A) \ (A'*y);

subplot(2,2,2);
plot(t, polyval(p, t), t, y, '.')
title('Polynomial approximation (degree = 3)')
xlabel('t')
ylabel('plyval(p,t)-degree')

%% Polynomial approximation (degree = 4)

A = bsxfun(@power, t, [4 3 2 1 0]);
p = (A'*A) \ (A'*y);

subplot(2,2,3);
plot(t, polyval(p, t), t, y, '.')
title('Polynomial approximation (degree = 4)')
xlabel('t')
ylabel('plyval(p,t)-degree')





