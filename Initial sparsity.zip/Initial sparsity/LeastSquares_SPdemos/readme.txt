Least Squares with Examples in Signal Processing.

Matlab examples for the lecture notes.

http://eeweb.poly.edu/iselesni/lecture_notes/least_squares/

Each folder contains a different example. The data for each example is located in the respective folders.

Folder list:

deconvolutionlinear_predictionmissing_datapoly_approxsmoothingspeech_declippingsystem_id


----

Ivan Selesnick
selesi@poly.edu
Polytechnic Inst. of NYU