function c = AT(y, M, N)
    c = fft([y; zeros(N-M, 1)]); % 这里c的形状和方括号的其实是一样的，只不过这里进行了补全
end

%% y = Ac------>A^H = cy^(-1)