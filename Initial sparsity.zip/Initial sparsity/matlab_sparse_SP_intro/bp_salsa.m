function [x, cost] = bp_salsa(y, A, At, p, mu, Nit, lambda)

% 此时还没有加降噪。

% x = bp_salsa(y, A, At, p, mu, Nit)
%
% BASIS PURSUIT
% Minimize || x ||_1 such that y = A x      其实感觉就是求无穷解里最小解的问题
% where A At = p I
%
% INPUT
%   y     : data            A就是ifft,AT就是fft
%   A, At : function handles for A and its conj transpose
%   p     : Parseval constant 即A*AT = PI
%   mu    : ADMM parameter (inverse step size) 即反向步长
%   Nit   : number of iterations 即迭代次数
%
% OUTPUT
%   x     : solution to BP problem
%
% [x, cost] = bp_salsa(...) returns cost function history 即损失函数
%
% salsa_bp(..., lambda) minimizes ||lambda .* x||_1

% Ivan Selesnick
% NYU-Poly
% selesi@poly.edu
% March 2012

% The algorithm is a variant of SALSA (Afonso, Bioucas-Dias, Figueiredo,
% SALSA出自论文<Fast image recovery using variable splitting and constrained optization>
% IEEE Trans Image Proc, 2010, p. 2345)

if nargin < 7           % 函数输入参数项目
    lambda = 1;         % 这是默认值
end
%% 首先输入的Y是什么东西呢




%% BP问题就是减少小幅值频率，这里使用的是SALSA算法，感谢这也是BPD。
% SALSA就是已知待优化目标，然后加速及更好的优化求解。
%% 原代码
% Initialization
x = At(y);              % AT函数是fft
d = zeros(size(x));     
cost = zeros(1,Nit);

% 算法这么写的前提是 A*AT = PI ，Algorithm 2
for i = 1:Nit
    u = soft(x + d, 0.5*lambda/mu) - d;         % soft(x,T)->y = max(1 - T./abs(x), 0) .* x;
    d = (1/p) * At(y - A(u));                   % A函数是ifft      A*AT = PI    
    x = d + u;                                  % x - u = d
    cost(i) = sum(lambda(:) .* abs(x(:)));
end

