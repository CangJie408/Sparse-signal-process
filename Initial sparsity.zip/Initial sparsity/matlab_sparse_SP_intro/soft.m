function y = soft(x, T)
% y = soft(x, T)
%
% SOFT THRESHOLDING         软阈值操作函数
% for real or complex data.
%
% INPUT
%   x : data (scalar or multidimensional array)     标量 或者 多维数据
%   T : threshold (scalar or multidimensional array) 阈值
%
% OUTPUT
%   y : output of soft thresholding
%
% If x and T are both multidimensional, then they must be of the same size.

y = max(1 - T./abs(x), 0) .* x;  % 就当时特别不同的软阈值操作函数，看自己需求

% Ivan Selesnick
% NYU-Poly
% selesi@poly.edu
