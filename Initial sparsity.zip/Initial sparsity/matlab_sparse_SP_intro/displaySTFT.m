function displaySTFT(c, fs, T, dblim)

% displaySTFT(c, fs, T, dblim)
%
% DISPLAY STFT (short-time Fourier transform)
%
% INPUT
%   c     : STFT coefficient (2D array)
%   fs    : sampling rate (samples/second)
%   T     : signal duration (seconds)
%   dblim : limits for colorbar in Db

[Nf, Nt] = size(c);

% imagsc使用缩放颜色显示图像
imagesc([0 T], [0 fs/2]/1e3, 20*log10(abs(c(1:Nf/2,:))), dblim)
axis xy         % 自动选择X轴和Y轴
ylabel('Frequency (kHz)')
xlabel('Time (seconds)')

cm = colormap( 'jet' );    % 查看并设置当前颜色图
cm = cm(end:-1:1,:);
colormap(cm);

CB = colorbar;
set(CB, 'ytick', (-50:10:0))

shg

