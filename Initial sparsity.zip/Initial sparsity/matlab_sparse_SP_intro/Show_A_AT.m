M = 100;
N = 256;
y = rand(M,1);
C = (1/N)*AT(y,M,N); % 这是傅里叶变换
y2 = A(C,M,N);       % 这是反傅里叶变换，这里这么处理对幅度上有一个放大作用对于原信号
recon_err = y2-y;
fprintf('Maximum reconstruction error; %g\n',max(recon_err)); 
% 傅里叶变换与反傅里叶反变换    矩阵与复共轭矩阵

%% test
xx = -10:2:10;
yy = sign(xx).*(abs(xx) - 2);
plot(yy);


%% Create signal
I = sqrt(-1);
M = 100;
m = (0:M-1);
f1 = 10.5;
x = exp(I*2*pi*f1/M*m);
figure(1)
clf
subplot(2,1,1)
plot(m,real(x),m,imag(x),'--')
xlabel('Time (samples)')
title('Signal');
legend('Real part','Iamginary part')
box off
yliml = [-1.4,1.8];
ylim(yliml)

%% Spectrum (using DFT)
X = fft(x);
stem(m,abs(X),'marker','none')
xlabel('Frequency (DFT index)')
title('(A) Fouries coefficients (DFT)');
box off
print('DFT')                % 但凡在计算机上操作的都是离散傅里叶变换

%% Oversampled DFT:Least squares
N = 256;
X = (1/N)*AT(x',M,N);

figure(2)
clf
stem(abs(X),'marker','none')
title('(B) Fourier coefficients (least square solution)');
xlabel('Frequency (index)')
box off
xlim([0 N])

%% Oversample DFT: Basis pursuit
% Define functions (Matlab functions handles)
H = @(x) A(x,M,N);
HT = @(x) AT(x,M,N);

% Define algorithm parameters
p = N;          % p ：Parseval constant
Nit = 100;      % Nit: number of iterations
mu = 5;         % mu : ADMN parameter

% Run basis pursuit algorithm
[c,cost] = bp_salsa(x',H,HT,p,mu,Nit);

%% Display cost function history of basis pursuit algorithm
figure(1)
clf
subplot(3,3,[1 2 4 5])
plot(cost)
title('Cost function history');
xlabel('Iteration')
itl = 4;
del = cost(itl) - min(cost);
ylim([min(cost)-0.1*del cost(itl)])
xlim([0 Nit])
box off

%% Display Fourier coefficients obtained by basis pursuit
figure(2)
clf
subplot(2,1,1)
stem(0:N-1,abs(c),'marker','none')
title('(C) Fourier coefficients (basis pursuit solution)');
xlabel('Frequency (index)')
box off
xlim([0 N])


%% Basis pursuit denoising(BPD)

%% Load sppech waveform data
[sp1, fs] = audioread('data/sp1.wav');

M = 500;                        % M : length of signal
s = sp1(5500+(1:M));            % s : signal (without noise)
                                % 截取 5501->6000

plot(s)
box off
title('Speech waveform')

%% Create noisy signal
% Make noisy sinal by adding white Gaussian noise
w = 0.1 * randn(M,1);
y = s + w;

plot(y)
box off
ylim([-0.5 0.7]);
title('Noisy signal');
xlabel('Time (samples)')

%% Spectrum of noisy signal
N = 2^10;
Y = (1/N)*fft(y,N);

plot(abs(Y))
xlim([0 N/2])
box off
title('(A) Fourier coefficients (FFT) of noisy signal');
xlabel('Frequency (index)')

%% Basis pursuit denoising
% Perform basis pursuit denosing using iteratitive algorithm

H = @(x) A(x,M,N);
HT = @(x) AT(x,M,N);
p = N;
lambda = 7;
Nit = 50;
mu = 500;

[c,cost] = bpd_salsa(y,H,HT,p,lambda,mu,Nit);
plot(cost)
title('Cost function history');
xlabel('Iteration')
itl = 5;
del = cost(itl) - min(cost);
ylim([min(cost)-0.1*del cost(itl)])
xlim([0 Nit])
box off


%% Display BPD Fourier coefficients
plot(abs(c))
xlim([0 N/2])
box off
title('(B) Fourier coefficents (BPD solution)');
xlabel('Frequency (index)')

%% Compute denoised signal
g = H(c);
g = real(g);

figure(1)
clf
subplot(2,1,1)
plot(g)
box off
ylim(ylim1);
title('Denoising using BPD');
xlabel('Time (samples)')

%% Example: Deconvoluton using BPD

%% Create spike signal
N = 100;
s = zeros(N,1);
k = [20 45 70];
a = [2 -1 1];
s(k) = a;

figure(1)
clf
subplot(2,1,1)
stem(s,'marker','none')
box off
title('Sparse signal')
ylim1 = [-1.5 2.5];
ylim(ylim1)
xlabel('')

%% Create observed signal
L = 4;
h = ones(L,1)/L;
M = N+L-1; % 100+4-1 = 103
w = 0.03 * randn(M,1);
y = conv(h,s) + w;

figure(2)
clf
subplot(2,1,1)
plot(y)
box off
xlim([0 M])
title('observed signal');
xlabel('')

%% Create convolution matrix H
H = sparse(M,N);        % 生成M×N全零稀疏矩阵
e = ones(N,1);
for i = 0:L-1
    H = H + spdiags(h(i+1)*e,-i,M,N);       % 提取非零对角线并创建稀疏带状矩阵
end
issparse(H)

%% Display structure of convolution matrix. Note that the matrix is banded(sparse).
figure(1)
clf
spy(H(1:24,1:21))

%% Find the BPD solution to the deconvolution problem
lambda = 0.05;
Nit = 50;
mu = 0.2;

[x_BPD,cost] = bpd_salsa_sparsemtx(y,H,lambda,mu,Nit);

%% Display cost function history of BPD algorithms
figure(1)
clf
plot(cost);
title('Cost function history');
xlabel('Iteration');
itl = 5;
del = cost(itl) - min(cost);
ylim([min(cost) - 0.1*del cost(itl)])
xlim([0 Nit])
box off

%% Example:Estimation of missing samples using BP

%% Define oversampled DFT functions
M = 500;
N = 2^10;
Afun = @(x) A(x,M,N);
ATfun = @(x) AT(x,M,N);
p = N;

%% Load speech waveform data
[sig,fs] = audioread('data/sp1.wav');
x = sig(5000+(1:M));
n = 0:N-1;
X = (1/N)*ATfun(x);

%% Display signal and its DFT
figure(1)
clf
subplot(2,1,1)
plot(x)
title('Speech waveform');
xlabel('Time (samples)');
box off
ymax = 0.6;
ylim([-1 1]*ymax)
set(gca,'ytick',[-0.5 0 0.5])

subplot(2,1,2)
plot(n, abs(X))
xlabel('Frequency (DFT index)')
xlim([0 N/2])
box off
ax = axis;
txt = sprintf('DFT coefficients,  L1 norm = %.2f',sum(abs(X)));
title(txt);

%% Example:signal separation using dual basis pursuit
%% Create signal
M=150;
m=(0:M-1);
y = cos(0.1*pi*m)+cos(0.15*pi*m);
y = y/1.5;
y = y+3*(m == 50);
y = y - 3*(m == 70);
ymax = max(abs(y));

plot(m,y);
xlim([0 M]);
ylim([-ymax ymax])
box off
title('signal')
xlabel('')

%% Define the two Parseval transforms
A1 = @(x) x;
A1T = @(x) x;
p1= 1;
N = 256;
A2 = @(x) A(x,M,N)/sqrt(N);
A2T = @(x) AT(x,M,N)/sqrt(N);
p2 = 1;

E = sum(abs(y(:)).^2);
c1 = A1T(y);
c2 = A2T(y);
E1 = sum(abs(c1(:)).^2);
E2 = sum(abs(c2(:)).^2);
fprintf('Signal energy = %.3e\n', E)
fprintf('Transform 1 energy = %.3e\n', E1/p1)
fprintf('Transform 2 energy = %.3e\n', E2/p2)

%% 此处进行测试
M = 100;
m = (0:M-1)';
y = exp(2/M*m);   
w = randn(M,1);
y = y + w;
ft = fft(y);
ftA = AT(y,M,100);
subplot(2,1,1);
plot(ft);
subplot(2,1,2);
plot(ftA);
ift = ifft(ft);
iftA = A(ftA,M,100);
subplot(2,1,1);
plot(ift);
subplot(2,1,2);
plot(iftA);