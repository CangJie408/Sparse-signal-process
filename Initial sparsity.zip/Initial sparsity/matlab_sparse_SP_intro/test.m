function [x,j] = test(y,H,lambda,alpha,Nit)
j = zeros(1,Nit);
x = 0*H'*y;
T = lambda/(2*alpha);
for k = 1:Nit
    Hx = H*x;
    j(k) = sum(abs(Hx(:) - y(:)).^2) +lambda*sum(abs(x(:)));
    x = soft(x+(H'*(y-Hx))/alpha,T);
end


h = [1 2 3 4 3 2 1]/16;
N = 100;
H = convmtx(h',N);
lambda = 0.1;
alpha = 1;
Nit = 500;
[x, j] = test(y, H, lambda, alpha, Nit);