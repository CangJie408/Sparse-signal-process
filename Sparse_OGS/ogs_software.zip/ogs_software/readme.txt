Translation-Invariant Shrinkage/Thresholding of Group Sparse Signals

Web: http://eeweb.poly.edu/iselesni/ogs/

This software implements the 'Overlapping Group Shrinkage' (OGS) algorithm in the paper:

Translation-Invariant Shrinkage/Thresholding of Group Sparse Signals
Preprint: May 2012
Revised: March 2013

The software reproduces examples and figures given in the paper.
The implementation here is for 1D and 2D signals.
OGS can be readily implemented for higher dimensional signals as well.

Example 1 : 1D signal denoising using OGS
Example 2 : Speech denoising using OGS

Example 2 compares OGS with the block thresholding (Yu, Mallat, Bacry, 2008).
We used the authors' software downloaded from:
http://www.cmap.polytechnique.fr/~yu/research/ABT/samples.html

------------------------------------------------

Main functions:

 ogshrink		overlapping group shrinkage (OGS)
 ogshrink2	2D overlapping group shrinkage (OGS)
 soft		soft thresholding

 stft		short-time Fourier transform (STFT), 50% overlapping
 istft		inverse STFT

Examples

 Example0		verifies OGS with group size K = 1 is soft thresholding
 Example1		1D signal denoising
 Example2		speech denoising

------------------------------------------------

Po-Yu Chen		Email: poyupaulchen@gmail.com
Ivan W. Selesnick		Email: selesi@poly.edu

Polytechnic Institute of New York University 
Electrical and Computer Engineering 
New York, USA

This research was support by the NSF under Grant No. CCF-1018020.
