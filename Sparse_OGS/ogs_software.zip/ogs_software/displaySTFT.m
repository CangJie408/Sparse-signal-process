function displaySTFT(X, fs, Nf, dBlim)
% displaySTFT(X, fs, Nf, dBlim)
% Display the short-time Fourier transform coefficients X
%
% INPUT
%   X: STFT coefficients (2D array)
%   fs: sampling rate
%   Nf: length of FFT
%   The block length is assumed to be Nf/2

[Nx, Ny] = size(X);

XdB = 20 * log10( abs( X(1:round(Nx/2) , : )) );

if nargin == 4
    imagesc([0 Ny/fs*Nf/2], [0 fs/2/1000], XdB, dBlim);
else
    imagesc([0 Ny/fs*Nf/2], [0 fs/2/1000], XdB);
end

cm = colormap('gray');
cm = cm(end:-1:1,:);
colormap(cm);

axis xy
xlabel('Time (seconds)')
ylabel('Frequency (kHz)')

% CB = colorbar;
% set(CB, 'ytick', (-50:10:0))

shg
