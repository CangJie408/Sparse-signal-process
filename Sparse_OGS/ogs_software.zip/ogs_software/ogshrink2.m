function [a, cost] = ogshrink2(y, K1, K2, lam, Nit)
% [a, cost] = ogshrink2(y, K1, K2, lam, Nit);
% 2D overlapping group shrinkage (OGS)
% Minimizes the cost function with respect to a
%
% cost = 0.5*sum(sum(abs(y - a).^2)) + lam * sum(sqrt(conv(abs(a).^2, ones(K1,K2))));
%
% INPUT
%   y      : 2-D  noisy signal (2D array)
%   K1, K2 : size of group
%   lam    : regularization parameter
%   Nit    : number of iterations
%
% OUTPUT
%   a    : output (denoised signal)
%   cost : cost function history

% Po-Yu Chen and Ivan Selesnick
% Polytechnic Institute of New York University
% New York, USA
% March 2012

a = y;                  % initialize
h1 = ones(K1,1);        % for convolution
h2 = ones(K2,1);        % for convolution
cost = zeros(1,Nit);
for it = 1:Nit
    r = sqrt(conv2(h1, h2, abs(a).^2));
    cost(it) = 0.5*sum(sum(abs(y - a).^2)) + lam * sum(r(:));
    v = 1 + lam*conv2(h1, h2, 1./r);
    v = v(K1:end+1-K1, K2:end+1-K2);
    % In newer MATLAB, the above 2 lines can be replaced with 1 line:      
    % v = 1 + lam*conv2(h1, h2, 1./r, 'valid');
    a = y./v;
end
