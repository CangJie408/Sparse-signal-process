% script Block thresholding
% G. Yu, S. Mallat, E. Bacry, "Audio Denoising by Time-Frequency Block
% Thresholding", IEEE Trans. on Signal Processing, vol 56, no. 5, pp. 1830-1839, May 2008.

% Clean signal, just for comparison
f = wavread('./moz1_11kHz.wav');

% noisy signal, contaminated by Gaussian white noise with sigma = 0.047.
% sigma needs to be estimated somehow. (see "Audio Denoising with Time-Frequency Block Thresholding", 
% G. Yu, S. Mallat, E. Bacry, 2008)
fn = wavread('./moz1_5dBnoisy.wav');
sigma_noise = 0.047;
% sampling rate of the signal (Hz)
f_sampling = 11025;

tmp = sprintf('The SNR of the noisy signal is %.2f', get_SNR(f,fn));
disp(tmp)

% short-time fourier window length (ms)
time_win = 50;

[f_rec, AttenFactorMap, flag_depth] = BlockThresholding(fn, time_win, f_sampling, sigma_noise);

tmp = sprintf('The SNR of the denoised signal is %.2f', get_SNR(f,f_rec));
disp(tmp)


wavwrite(f_rec, f_sampling, './moz1_denoised.wav');
disp('The denoised signal has been written to the file ./moz1_denoised.wav'); 
