Reference software: Audio Denoising by Time-Frequency Block Thresholding

Run demo_blockthresholding.m to see an example. 

Reference: 
G. Yu, S. Mallat, E. Bacry, "Audio Denoising by Time-Frequency Block
Thresholding", IEEE Trans. on Signal Processing, vol 56, no. 5, pp. 1830-1839, May 2008.

