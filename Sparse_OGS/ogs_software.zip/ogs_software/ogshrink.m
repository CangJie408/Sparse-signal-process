function [a, cost] = ogshrink(y, K, lam, Nit)
% [a, cost] = ogshrink(y, K, lam, Nit);
% Overlapping group shrinkage (OGS)
% Minimizes the cost function with respect to a
%
% cost = 0.5 * sum(abs(y - a).^2) + lam * sum(sqrt(conv(abs(a).^2, ones(1,K))));
%
% INPUT
%   y   : 1-D  noisy signal (vector)
%   K   : size of group
%   lam : regularization parameter
%   Nit : number of iterations
%
% OUTPUT
%   a    : output (denoised signal)
%   cost : cost function history

% Po-Yu Chen and Ivan Selesnick
% Polytechnic Institute of New York University
% New York, USA
% March 2012

a = y;                  % initialize
h = ones(1,K);          % for convolution 
cost = zeros(1,Nit);
i = (a ~= 0);
for it = 1:Nit
    r = sqrt(conv(abs(a).^2, h));
    cost(it) = 0.5*sum(abs(y - a).^2) + lam * sum(r);
    v = 1 + lam*conv(1./r, h);
    v = v(K:end+1-K);
    % In newer MATLAB, the above 2 lines can be replaced with 1 line:      
    % v = 1 + lam*conv(1./r, h, 'valid');
    a = y./v;    
end