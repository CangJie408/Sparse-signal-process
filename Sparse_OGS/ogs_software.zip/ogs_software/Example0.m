%% Example 0: Overlapping group shrinkage (OGS) with group size K = 1
% This program verifies that OGS gives the same result as soft thresholding when the group
% size is just K = 1.
%
%  Po-Yu Chen and Ivan Selesnick
% Polytechnic Institute of New York University
% New York, USA
% March 2012

%% Start

clear
close all

%% Soft-thresholding

M = 4;
y = -M:0.1:M;

T = 1;              % T : Threshold
x_soft = soft(y, T);

figure(1)
clf
plot(y, x_soft)
title('Soft threshold function')
axis([-M M -M M])
axis square

%% Overlapping group shrinkage

K = 1;              % K : group size

lambda = 1;         % lambda : regularization parameter for OGS

Nit = 30;           % Nit : number of iterations

figure(2)
clf

% OGS iterative algorithm
x = y;                  % initialize
h = ones(1,K);          % for convolution
cost = zeros(1,Nit);
for it = 1:Nit
    r = sqrt(conv(abs(x).^2, h));
    cost(it) = 0.5*sum(abs(y - x).^2) + lambda * sum(r);
    v = 1 + lambda*conv(1./r, h, 'valid');
    x = y./v;
    if any(it == [2 5 15])
        line(y, x)
    end
end

axis square
xlabel('y')
ylabel('a')
axis([-M M -M M])
title('OGS: iterations 2, 5, 15')

print -dpdf 'figures/Example0'

%% Cost function history

figure(2)
clf
plot(cost)
title('OGS cost function history')
xlabel('Iteration')



