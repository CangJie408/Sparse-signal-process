%% demo1: group-sparse thresholding, 1D data
% This demo uses group-sparse thresholding (OGS) for
% 1D signal denoising.
%
% Po-Yu Chen and Ivan Selesnick, August 2013
%
% Revised, May 2016
%
% Reference:
% P. Y. Chen and I. W. Selesnick,
% "Group-Sparse Signal Denoising: Non-Convex Regularization, Convex Optimization,"
% IEEE Transactions on Signal Processing, vol. 62, no. 13, pp. 3464-3478, July 1, 2014.
% doi: 10.1109/TSP.2014.2329274

%% Set up

clear

rmse = @(err) sqrt(mean(abs(err).^2));

% Set random number generator for reproducibility
rng('default')
rng(1)

%% Make signal

% N : length of signal
N = 100;                     

% s : noise-free signal
s = zeros(N,1);              
s(20+(-3:3)) = [2 3 4 5 4 3 2];
s(40+(-3:3)) = [3 -2 -4 5 2 4 -3];
s(60+(-3:3)) = [3 4 2 5 -4 -2 -3];
s(80+(-3:3)) = [3 -4 -2 5 4 2 -3];

% y : signal + noise
y = s + (2/3) * randn(N, 1);

%% Plot signals

ylim1 = [-7 7];

figure(1)
clf
subplot(2, 1, 1)
stem(s, 'marker', 'none')
ylim(ylim1);
title('Signal');

subplot(2, 1, 2)
stem(y, 'marker', 'none')
title(sprintf('Signal + noise (RMSE = %3.2f)', rmse(s - y)));
ylim(ylim1);

orient portrait
print -dpdf figures/demo1_data


%% Denoising using OGS
% Use the function ogs1 

K = 5;                  % K : group size
lam = 0.5;              % lam : regularization parameter
x = ogs1(y, K, lam);    % OGS algorithm

figure(2), clf
subplot(2, 1, 1)
stem(x, 'marker', 'none')
ylim(ylim1);
title(sprintf('OGS thresholding (RMSE = %3.2f)', rmse(s - x)));

%% Denoising using OGS with 'mcp' penalty
% Use the function ogs1 with optional arguments to 
% specify penalty and rho parameter (rho between 0 and 1).
% We usually set rho between 0.8 and 1.0.

K = 5;              % K : group size
lam = 0.5;          % lam : regularization parameter
pen = 'mcp';        % mcp penalty
rho = 0.9;          % rho between 0 and 1

x = ogs1(y, K, lam, pen, rho);  % OGS algorithm

subplot(2, 1, 2)
stem(x, 'marker', 'none')
ylim(ylim1);
title(sprintf('OGS using %s penalty (RMSE = %3.2f)', pen, rmse(s - x)));

orient portrait
print -dpdf figures/demo1_ogs
