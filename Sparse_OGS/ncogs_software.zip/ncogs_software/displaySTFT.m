function displaySTFT(X, Fs, T, dBlim)

% displaySTFT(X, Fs, T)
% Display the short-time Fourier transform coefficients X
%
% INPUT
%   X  : STFT coefficients (2D array)
%   Fs : sampling rate (samples/second)
%   T  : duration of signal (seconds)
%
% Use displaySTFT(X, Fs, T, dBlim) to specify limits

XdB = 20 * log10( abs(X) );

imagesc( [0 T], [0 Fs/1000],  XdB);

if nargin == 4
    caxis(dBlim)
end

cm = colormap( 'gray' );
cm = cm(end:-1:1,:);
colormap(cm);

axis xy
xlabel( 'Time (seconds)' )
ylabel( 'Frequency (kHz)' )

xlim([0 T])
ylim([0 Fs/2/1000])

% CB = colorbar;
% set(CB, 'ytick', (-50:10:0))

shg
