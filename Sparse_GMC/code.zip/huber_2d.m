function S = huber_2d(B, x1, x2)
% S = huber_2d(B, x1, x2)
%
% % Example
% B = [1 0; 1 1; 0 1];
% x = linspace(-2, 2, 27);
% [x1, x2] = meshgrid(x, x);
% S = huber_2d(B, x1, x2);
% figure(1)
% clf
% mesh(x, x, S, 'EdgeColor', 'black')
% axis square

% h : scalar huber function
h = @(t) min( 0.5 * t.^2 , 0.5 + min( abs(t-1), abs(t+1) ));

S = inf(size(x1));   % initialize

K = B'*B;

Kx1 = K(1,1)*x1 + K(1,2)*x2;
Kx2 = K(2,1)*x1 + K(2,2)*x2;
d = det(K);

if d < 1e-8
    
    disp('K nearly singular')
    S = min(S, h(Kx2)/K(2,2) );
    S = min(S, h(Kx1)/K(1,1) );
    
else
    
    S = min(S, h(Kx2)/K(2,2) + x1.^2 * d / K(2,2) / 2 );
    S = min(S, h(Kx1)/K(1,1) + x2.^2 * d / K(1,1) / 2 );
    
    u = [+1; +1];
    b = K\u;
    S = min(S, abs( x1 - b(1) ) + abs( x2 - b(2) ) + u' * b / 2);
    
    u = [-1; -1];
    b = K\u;
    S = min(S, abs( x1 - b(1) ) + abs( x2 - b(2) ) + u' * b / 2);
    
    u = [+1; -1];
    b = K\u;
    S = min(S, abs( x1 - b(1) ) + abs( x2 - b(2) ) + u' * b / 2);
    
    u = [-1; +1];
    b = K\u;
    S = min(S, abs( x1 - b(1) ) + abs( x2 - b(2) ) + u' * b / 2);
    
end
