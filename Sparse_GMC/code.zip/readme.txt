Software to accompany the paper:

I. Selesnick, 'Sparse Regularization via Convex Analysis'
IEEE Transactions on Signal Processing, 2017.

Program listing (MATLAB)

srls_GMC
	Sparse-regularized least squares (srls) using
	the proposed GMC penalty.
srls_L1
	Sparse-regularized least squares (srls) using
	the L1 norm
GMC_demo
	Demonstration (example 1 from paper) of signal
	denoising based on frequency-domain sparsity

huber_1d_demo
	Shows one-dimensional Huber function and MC penalty
huber_2d_demo
	Shows generalized Huber function and generalized MC 
	penalty in two-dimensions
huber_2d
	Calculates two-dimensional generalized Huber function

Ivan Selesnick
Department of Electrical and Computer Engineering
Tandon School of Engineering
New York University
http://eeweb.poly.edu/iselesni/
selesi@nyu.edu
						March 18, 2017