%% huber_1d_demo
%
%  Ivan Selesnick
%  June 2016

%% Define Huber function

huber = @(t) min( 0.5 * t.^2, min( abs(t-1) + 0.5, abs(t+1) + 0.5 ));

%% Huber function

T = 3;
t = linspace(-T, T, 101);

figure(1)
clf
plot(t, huber(t));
xlabel('x')
title('Huber function')
axis([-T T 0 T])
axis image
print -dpdf ../results/Huber_1d

%% MC penalty

figure(2)
clf
plot(t, abs(t) - huber(t), [-T 0 T], [T 0 T], '--')
xlabel('x')
title('MC penalty function');
axis([-T T 0 T])
axis image
txt1 = text(1.5, 1.7, '|x|');
txt2 = text(1.5, 0.6, '\phi(x)');
print -dpdf ../results/MC_penalty_1d

%% scaled functions

sb = @(t, b) huber(b^2 * t) / b^2;

b_list = [1 0.5 sqrt(2) 1/sqrt(2)];

figure(1)
clf
subplot(2, 1, 1)
for b = b_list
    line(t, sb(t, b));
    text(T+0.1, T-0.5/b^2, sprintf('b = %.2f', b));
end
xlabel('x')
axis image
axis([-T T 0 T])
title('Scaled Huber function s(x)');

subplot(2, 1, 2)
for b = b_list
    line(t, abs(t) - sb(t, b));
    text(T+0.1, 0.5/b^2, sprintf('b = %.2f', b));
end
line([-T 0 T], [T 0 T], 'linestyle', '--')
xlabel('x')
axis([-T T 0 T])
axis image
title('Scaled MC penalty \phi(x)');

print -dpdf ../results/scaled_funs_1d
